﻿using Eindopdrachtperiode1.Model;
using Eindopdrachtperiode1.View;
using Eindopdrachtperiode1.ViewModel;
using System.Configuration;
using System.Data;
using System.Windows;

namespace Eindopdrachtperiode1
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            UserMessage userMessage = new UserMessage();
            MainWindow = new MainView()
            {
                DataContext = new MainViewModel(userMessage)
            };
            MainWindow.Show();
        }
    }

}

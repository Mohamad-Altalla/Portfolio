﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eindopdrachtperiode1.ViewModel
{
    internal class ContactInfoViewModel : Helpers.ObservableObject
    {
        #region fields
        private string _naam = null!;
        private string _telefoon = null!;
        private string _email = null!;
        #endregion
        #region properties
        public string Naam
        {
            get { return _naam; }
            set { _naam = value; }
        }

        public string Telefoon
        {
            get { return _telefoon; }
            set { _telefoon = value; }
        }

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        #endregion

        #region constructors
        public ContactInfoViewModel()
        {
            Naam = "Mohamad";
            Telefoon = "06 87 33 50 79";
            Email = "ps253191@summacollege.nl";
        }
        #endregion
    }
}

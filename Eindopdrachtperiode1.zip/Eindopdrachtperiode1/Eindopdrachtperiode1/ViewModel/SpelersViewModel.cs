﻿using Eindopdrachtperiode1.Databases;
using Eindopdrachtperiode1.Helpers;
using Eindopdrachtperiode1.Model;
using Eindopdrachtperiode1.Model.Eindopdrachtperiode1.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Eindopdrachtperiode1.ViewModel
{
    internal class SpelersViewModel : ObservableObject
    {
        #region Fields
        private Team? _selectedTeam;
        private readonly ObservableCollection<Team> _teams;

        private readonly UserMessage _userMessage;

        private Speler? _selectedSpeler;
        private Speler _speler;
        private readonly ObservableCollection<Speler> _spelers;
        #endregion

        #region Properties
        public ObservableCollection<Team> Teams { get; }

        public Team? SelectedTeam
        {
            get { return _selectedTeam; }
            set
            {
                _selectedTeam = value;
                OnPropertyChanged();
            }
        }
        
        public ObservableCollection<Speler> Spelers {  get; }

        public Speler? SelectedSpeler
        {
            get { return _selectedSpeler; }
            set
            {
                _selectedSpeler = value;
                if (_selectedSpeler != null)
                {
                    Speler = new Speler
                    {
                        Name = SelectedSpeler.Name,
                        Nationality = SelectedSpeler.Nationality,
                        Team = SelectedSpeler.Team,
                    };

                }
                OnPropertyChanged();
            }
        }

        public Speler Speler
        {
            get { return _speler; } //////////////////////
            set
            {
                _speler = value;
                OnPropertyChanged();
            }
        }
        #endregion

        #region Constructors
        
        public SpelersViewModel(UserMessage userMessage)
        {
            _userMessage = userMessage;
            try
            {

                using (AppDbContext db = new())
                {
                    Spelers = new ObservableCollection<Speler>(db.Spelers.ToList());
                    Teams = new ObservableCollection<Team>(db.Teams.ToList());

                }
            }
            catch (Exception e) 
            {
                _userMessage.Text = e.InnerException == null ? e.Message : e.InnerException.Message;
            }

            _speler = new Speler();


            AddSpelerCommand = new RelayCommand(ExecuteAddSpeler, CanExecuteAddSpeler);
            UpdateSpelerCommand = new RelayCommand(ExecuteUpdateSpeler, CanExecuteUpdateSpeler);
            DeleteSpelerCommand = new RelayCommand(ExecuteDeleteSpeler, CanExecuteDeleteSpeler);
            ClearCommand = new RelayCommand(ExecuteClearForm);
            }
        #endregion

        #region Commands
        public ICommand AddSpelerCommand { get; }
        public ICommand UpdateSpelerCommand { get; }
        public ICommand DeleteSpelerCommand { get; }
        public ICommand ClearCommand { get; }

        #endregion

        #region Methods
        private void ExecuteClearForm(object? obj)
        {
            Speler = new Speler(); // Reset de Speler
            SelectedSpeler = null; // Deselect
            OnPropertyChanged();
        }
        private void ExecuteAddSpeler(object? obj)
        {
            try
            {
                using (AppDbContext dbContext = new())
                {
                    Speler.Id = 0;
                    if (Speler.Team != null)
                    {
                        Speler.Team = dbContext.Teams.FirstOrDefault(t => t.Id == Speler.Team.Id); // Attach
                    }
                    dbContext.Spelers.Add(Speler);
                    dbContext.SaveChanges();
                }

                Spelers.Add(Speler);
                Speler = new(); // Reset
                OnPropertyChanged();
            }
            catch (Exception e)
            {
                _userMessage.Text = e.InnerException == null ? e.Message : e.InnerException.Message;
            }
        }


        private void ExecuteUpdateSpeler(object? obj)
        {

            if (SelectedSpeler == null) return;

            try
            {
                using (AppDbContext dbContext = new())
                {
                    Speler? databaseSpeler = dbContext.Spelers.Include(s => s.Team).FirstOrDefault(x => x.Id == SelectedSpeler.Id);
                    if (databaseSpeler != null)
                    {
                        databaseSpeler.Name = Speler.Name;
                        databaseSpeler.Nationality = Speler.Nationality;

                        if (Speler.Team != null)
                        {
                            databaseSpeler.Team = dbContext.Teams.FirstOrDefault(t => t.Id == Speler.Team.Id);
                        }

                        dbContext.SaveChanges();
                        SelectedSpeler.Team = Speler.Team;
                    }
                }

                Speler = new Speler();
                OnPropertyChanged();
            }
            catch (Exception e)
            {
                _userMessage.Text = e.InnerException == null ? e.Message : e.InnerException.Message;
            }
        }


        private bool CanExecuteAddSpeler(object? obj)
        {
            OnPropertyChanged();

            return
                   !string.IsNullOrEmpty(Speler.Name) &&
                  !string.IsNullOrEmpty(Speler.Nationality);
        }

        private bool CanExecuteUpdateSpeler(object? obj)
        {
            OnPropertyChanged();

            return
                   !string.IsNullOrEmpty(Speler.Name) &&
                   !string.IsNullOrEmpty(Speler.Nationality);

        }


        private void ExecuteDeleteSpeler(object? obj)
        {
            if (SelectedSpeler == null) return;
            try
            {
                using (AppDbContext dbContext = new())
                {
                    Speler? databaseSpeler = dbContext.Spelers.FirstOrDefault(x => x.Id == SelectedSpeler.Id);
                    if (databaseSpeler != null)
                    {
                        dbContext.Spelers.Remove(databaseSpeler);
                        dbContext.SaveChanges();
                    }
                }

                Spelers.Remove(SelectedSpeler);
                SelectedSpeler = null;
            }
            catch (Exception e)
            {
                _userMessage.Text = e.InnerException == null ? e.Message : e.InnerException.Message;
            }
        }

        private bool CanExecuteDeleteSpeler(object? obj)
        {
            return SelectedSpeler != null;
        }
        #endregion
    }
}


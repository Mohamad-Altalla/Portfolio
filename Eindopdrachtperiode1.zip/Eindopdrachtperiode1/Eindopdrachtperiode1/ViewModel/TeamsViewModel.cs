﻿using Eindopdrachtperiode1.Databases;
using Eindopdrachtperiode1.Helpers;
using Eindopdrachtperiode1.Model;
using Eindopdrachtperiode1.Model.Eindopdrachtperiode1.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml.Linq;

namespace Eindopdrachtperiode1.ViewModel
{
    class TeamsViewModel : ObservableObject
    {
        #region Fields
        private Team _currentTeam = new Team();
        private Team? _selectedTeam;

        private readonly UserMessage _userMessage;
        private readonly ObservableCollection<Team> _teams;
        #endregion

        #region Properties
        public ObservableCollection<Team> Teams { get; private set; }

        public Team? SelectedTeam
        {
            get { return _selectedTeam; }
            set
            {
                _selectedTeam = value;
                if (_selectedTeam != null)
                {
                    CurrentTeam = new Team
                    {
                        Name = _selectedTeam.Name,
                        Nationality = _selectedTeam.Nationality
                    };
                }
                OnPropertyChanged();
            }
        }

        public Team CurrentTeam
        {
            get { return _currentTeam; }
            set
            {
                _currentTeam = value;
                OnPropertyChanged();
            }
        }
        #endregion

        #region Commands
        public ICommand AddTeamCommand { get; }
        public ICommand UpdateTeamCommand { get; }
        public ICommand DeleteTeamCommand { get; }

        #endregion

        #region Constructors
        public TeamsViewModel()//UserMessage userMessage
        {
            //_userMessage = userMessage;

            try
            {
                using (AppDbContext db = new())
                {
                    Teams = new ObservableCollection<Team>(db.Teams.ToList());
                }
            }
            catch (Exception e)
            {
                _userMessage.Text = e.InnerException == null ? e.Message : e.InnerException.Message;
            }

            AddTeamCommand = new RelayCommand(ExecuteAddTeam, CanExecuteAddTeam);
            UpdateTeamCommand = new RelayCommand(ExecuteUpdateTeam, CanExecuteUpdateTeam);
            DeleteTeamCommand = new RelayCommand(ExecuteDeleteTeam, CanExecuteDeleteTeam);
        }
        #endregion

        #region Methods

        private void ExecuteAddTeam(object? obj)
        {

            try
            {


                using (AppDbContext dbContext = new())
                {
                    CurrentTeam.Id = 0;
                    dbContext.Teams.Add(CurrentTeam);
                    dbContext.SaveChanges();
                }
                Teams.Add(CurrentTeam);

                CurrentTeam = new Team();
                OnPropertyChanged();

            }
            catch (Exception e) {
                _userMessage.Text = e.InnerException == null ? e.Message : e.InnerException.Message;

            }

        }

        private bool CanExecuteAddTeam(object? obj)
        {
            return !string.IsNullOrWhiteSpace(CurrentTeam.Name) &&
                   !string.IsNullOrWhiteSpace(CurrentTeam.Nationality);
        }

        private void ExecuteUpdateTeam(object? obj)
        {
            if (SelectedTeam == null) return;

            try
            {
                using (AppDbContext dbContext = new())
                {
                    Team? databaseTeam = dbContext.Teams.FirstOrDefault(x => x.Id == SelectedTeam.Id);
                    if (databaseTeam != null)
                    {
                        databaseTeam.Name = CurrentTeam.Name;
                        databaseTeam.Nationality = CurrentTeam.Nationality;

                        dbContext.SaveChanges();
                    }
                }

                SelectedTeam.Name = CurrentTeam.Name;
                SelectedTeam.Nationality = CurrentTeam.Nationality;

                CurrentTeam = new Team();
            }
            catch (Exception e)
            {
                _userMessage.Text = e.InnerException == null ? e.Message : e.InnerException.Message;
            }
        }


        private bool CanExecuteUpdateTeam(object? obj)
        {
            return SelectedTeam != null &&
                   !string.IsNullOrWhiteSpace(CurrentTeam.Name) &&
                   !string.IsNullOrWhiteSpace(CurrentTeam.Nationality);
        }

        private void ExecuteDeleteTeam(object? obj)
        {
            if (SelectedTeam == null) return;
            try
            {


                using (AppDbContext dbContext = new())
                {
                    Team? databaseTeam = dbContext.Teams.FirstOrDefault(x => x.Id == SelectedTeam.Id);
                    if (databaseTeam != null)
                    {
                        dbContext.Teams.Remove(databaseTeam);
                        dbContext.SaveChanges();
                    }
                }

                Teams.Remove(SelectedTeam);
                SelectedTeam = null;
            }
            catch (Exception e)
            {
                _userMessage.Text = e.InnerException == null ? e.Message : e.InnerException.Message;
            }
        }

        private bool CanExecuteDeleteTeam(object? obj)
        {
            return SelectedTeam != null;
        }

        #endregion
    }
}
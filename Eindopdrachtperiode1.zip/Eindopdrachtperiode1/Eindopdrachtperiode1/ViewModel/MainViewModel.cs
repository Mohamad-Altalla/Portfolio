﻿using Eindopdrachtperiode1.Helpers;
using Eindopdrachtperiode1.Model;
using Org.BouncyCastle.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Eindopdrachtperiode1.ViewModel
{
    internal class MainViewModel : Helpers.ObservableObject, IAppNavigation
    {
    #pragma warning disable CS8618
        public MainViewModel()
    #pragma warning restore CS8618
        {
        }

        #region fields
        private UserMessage _userMessage;
        private object _activeViewModel;
        #endregion

        #region constructors
        public MainViewModel(UserMessage userMessage)
        {
            
            _activeViewModel = new ContactInfoViewModel();
            
            UserMessage = userMessage;

            ShowContactInfoCommand = new RelayCommand(ExecuteShowContactInfo);
            ShowSpelersCommand = new RelayCommand(ExecuteShowSpelers);
            ShowTeamsCommand = new RelayCommand(ExecuteShowTeams);
        }
        #endregion

        #region properties
        public object ActiveViewModel
        {
            get { return _activeViewModel; }
            set
            {
                _activeViewModel = value;
                OnPropertyChanged();
            }
        }

        public UserMessage UserMessage
        {
            get { return _userMessage; }
            set { _userMessage = value; OnPropertyChanged(); }
        }
        #endregion

        #region commands
        public ICommand ShowSpelersCommand { get; }

        public ICommand ShowContactInfoCommand { get; }

        public ICommand ShowTeamsCommand { get; }
        #endregion

        #region methods
        private void ExecuteShowContactInfo(object? obj)
        {
            ActiveViewModel = new ContactInfoViewModel();
        }


        private void ExecuteShowSpelers(object? obj)
        {
            ActiveViewModel = new SpelersViewModel(UserMessage);
        }

        private void ExecuteShowTeams(object? obj)
        {
            ActiveViewModel = new TeamsViewModel();//UserMessage
        }
        #endregion
    }
}

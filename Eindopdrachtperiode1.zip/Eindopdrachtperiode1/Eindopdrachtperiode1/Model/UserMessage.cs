﻿using Org.BouncyCastle.Crmf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace Eindopdrachtperiode1.Model
{
    internal class UserMessage : Helpers.ObservableObject
    {
        #region Fields

        private string _text = string.Empty;
        private DispatcherTimer _timer;
        int counter = 0;

        #endregion

        #region Constructor

        public UserMessage()
        {
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(5);
            _timer.Tick += DispatcherTimer_Tick;
        }

        #endregion

        #region Properties

        public string Text
        {
            get { return _text; }
            set
            {
                _text = value;
                OnPropertyChanged();
              
                _timer.Start();
             
            }
        }

        #endregion

        #region Methods
        private void DispatcherTimer_Tick(object sender, EventArgs e)
        {          
            Text = string.Empty;
            _timer.Stop();
            MessageBox.Show("The timer has been stopped");
        
        }

        #endregion

    }
}

﻿using Eindopdrachtperiode1.Helpers;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Eindopdrachtperiode1.Model
{
    namespace Eindopdrachtperiode1.Model
    {
        [Table("teams")]
        [Index(nameof(Name), nameof(Nationality), IsUnique = true, Name = "UX_Teams")]
        internal class Team : ObservableObject
        {
            #region Fields
            private string _name = null!;
            private string _nationality = null!;
            #endregion

            #region Properties
            [Key]
            public int Id { get; set; } // Primary key for Team

            [StringLength(255), Required]
            public string Name
            {
                get => _name;
                set { _name = value; OnPropertyChanged(); }
            }

            [StringLength(255), Required]
            public string Nationality
            {
                get => _nationality;
                set { _nationality = value; OnPropertyChanged(); }
            }

            //1-to-Many Relationship with Speler
            public virtual ICollection<Speler> Spelers { get; set; } = new List<Speler>();
            #endregion

            #region Constructors
            public Team()
            {   
                Name = string.Empty;
                Nationality = string.Empty;
            }
            #endregion
        }
    }
}


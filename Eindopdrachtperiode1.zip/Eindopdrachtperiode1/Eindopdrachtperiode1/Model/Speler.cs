﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Eindopdrachtperiode1.Helpers;
using System.ComponentModel.DataAnnotations.Schema;
using Eindopdrachtperiode1.Model.Eindopdrachtperiode1.Model;

namespace Eindopdrachtperiode1.Model
{
        [Table("spelers")]
        [Index(nameof(Name), nameof(Nationality),
            IsUnique = true, Name = "UX_Spelers")]

    internal class Speler : ObservableObject
    {
        #region Fields
        private string _name = null!;
        private string _nationality = null!;
        private Team? _team;
        #endregion

        #region Properties 

        [Key]
        public int Id { get; set; }

        [StringLength(255), Required]
        public string Name
        {
            get { return _name; }
            set { _name = value; OnPropertyChanged(); }
        }

        [StringLength(255), Required]
        public string Nationality
        {
            get { return _nationality; }
            set { _nationality = value; OnPropertyChanged(); }
        }

        // Foreign Key 
        public int? TeamId { get; set; }

        // Navigation
        public virtual Team? Team
        {
            get { return _team; }
            set { _team = value; OnPropertyChanged(); }
        }
        #endregion

        #region Constructors

        public Speler()
        {
            Name = "";
            Nationality = "";
        }

        #endregion
    }
}
    


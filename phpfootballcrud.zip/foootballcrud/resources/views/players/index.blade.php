<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @vite('resources/css/index.css')

    <title>Home</title>
</head>
<body>
<div class="players-container">
<header><span>Players page </span> <a class="Create_button" href="{{route('players.create')}}">+</a></header>

<ul>
    @foreach($players as $player)



    <li><a href="{{route('players.show', $player->id)}}">{{$player->name}}</a>   </li>
        <div class="delete-edit">
    <div class="button-group">
        <form action="{{ route('players.destroy', $player->id) }}" method="POST" >
            @csrf
            @method('DELETE')
            <button type="submit" >Delete Player</button>




        </form>
        <a id="edit" href="{{ route('players.edit', $player->id)}}">Edit</a>

    </div>

</div>
    @endforeach



</ul>
</div>
</body>
</html>


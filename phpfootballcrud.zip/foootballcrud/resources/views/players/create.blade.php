@vite('resources/css/edit.css')
<div class="container">
<a class="players" href="{{ route('players.index') }}">← Back</a>
<form action="{{ route('players.store') }}" method="POST">
    @csrf
    <label for="Name">Name:</label>
    @if($errors->has('name') )
        <div class="text-red-700">{{ $errors->first('name') }}</div>
    @endif

    <input type="text" pattern="[A-Za-z\s]*" id="name" name="name" required>

    <label for="nationality">Nationality:</label>
    @if($errors->has('nationality') )
        <div class="text-red-700">{{ $errors->first('nationality') }}</div>
    @endif
    <input type="text" id="nationality" name="nationality" required>

    <label for="number">Number:</label>
    @if($errors->has('number') )
        <div class="text-red-700">{{ $errors->first('number') }}</div>
    @endif
    <input type="text" id="number" name="number" required>
    <button type="submit">Create</button>
</form>

</div>

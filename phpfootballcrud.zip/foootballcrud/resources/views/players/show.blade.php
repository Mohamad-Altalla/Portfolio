<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @vite('resources/css/show.css')
    <title>Document</title>
</head>
<body>

<div class="container">
    <a class="players" href="{{ route('players.index') }}">← Back</a>

    <h1>Your chosen player:</h1>
<p>Name: {{$player->genre}}</p>
<p>Nationality:  {{$player->founded}}</p>
    <p>Number:  {{$player->active_till}}</p>
</div>
</body>
</html>



<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @vite('resources/css/edit.css')

    <title>Edit Player</title>
</head>
<body>

<div class="container">
    <a class="players" href="{{ route('players.index') }}">← Back</a>
<form action="{{ route('players.update', $player->id) }}" method="POST">
    @csrf
    @method('PUT')

    <label for="name">Name:</label>
    @if($errors->has('name') )
        <div class="text-red-700">{{ $errors->first('name') }}</div>
    @endif

    <input type="text" id="name" name="name" value="{{ $player->name }}" required>

    <label for="Nat">Nationality:</label>
    @if($errors->has('nationality') )
        <div class="text-red-700">{{ $errors->first('nationality') }}</div>
    @endif
    <input type="text" id="nationality" name="nationality" value="{{ $player->nationality }}" required>

    <label for="number">Number:</label>
    @if($errors->has('number') )
        <div class="text-red-700">{{ $errors->first('number') }}</div>
    @endif
    <input type="text" id="number" name="number" value="{{ $player->number }}" required>
    <button type="submit">Update player</button>
</form>
</div>
</body>

</html>

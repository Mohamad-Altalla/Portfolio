<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PlayerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [   'name' => 'required|max:20',
            'nationality' => 'max:20',
            'number' => 'max:2',
            //
        ];
    }
    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return ["name.required" => "Player name is required",
            "name.max" => "Player name is too long (Max 20 characters)",
            "nationality.max" => "Nationality is too long (Max 20 characters)",
            "nationality.required" => "Nationality is required",
            "number.max" => "Number is too long (Max 2 characters)",
            "number.required" => "Number is required",];
    }

}

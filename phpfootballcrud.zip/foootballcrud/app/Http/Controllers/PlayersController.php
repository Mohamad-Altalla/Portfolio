<?php

namespace App\Http\Controllers;
use App\Http\Requests\PlayerRequest;
use App\Models\player;
use Illuminate\Http\Request;

class PlayersController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $players = player::all();

        return view('players.index', compact('players'));
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('players.create');

        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(PlayerRequest $request)
    {

        $player = $request->validated();

        player::create($player);

        return redirect()->route('players.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {

        $player = Player::findOrFail($id);
        return view('players.show', ['player' => $player]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $player = Player::findOrFail($id);
        return view('players.edit', compact('player'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'name' => 'required|max:20',
            'nationality' => 'max:20',
            'number' => 'max:2',
        ]);

        $player = Player::findOrFail($id);

        $player->update($validatedData);

        return redirect()->route('players.index')->with('message', 'Player updated successfully');
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        Player::destroy($id);

        return redirect()->route('players.index')->with('success', 'Player has been deleted');
        //
    }
}

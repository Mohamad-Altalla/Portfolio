<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/index.css'); ?>

    <title>Home</title>
</head>
<body>
<div class="players-container">
<header><span>Players page </span> <a class="Create_button" href="<?php echo e(route('players.create')); ?>">+</a></header>

<ul>
    <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



    <li><a href="<?php echo e(route('players.show', $player->id)); ?>"><?php echo e($player->name); ?></a>   </li>
        <div class="delete-edit">
    <div class="button-group">
        <form action="<?php echo e(route('players.destroy', $player->id)); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" >Delete Player</button>




        </form>
        <a id="edit" href="<?php echo e(route('players.edit', $player->id)); ?>">Edit</a>

    </div>

</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</ul>
</div>
</body>
</html>

<?php /**PATH C:\Users\moham\foootballcrud\resources\views/players/index.blade.php ENDPATH**/ ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/css/edit.css'); ?>
<div class="container">
<a class="players" href="<?php echo e(route('players.index')); ?>">← Back</a>
<form action="<?php echo e(route('players.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="Name">Name:</label>
    <?php if($errors->has('name') ): ?>
        <div class="text-red-700"><?php echo e($errors->first('name')); ?></div>
    <?php endif; ?>

    <input type="text" pattern="[A-Za-z\s]*" id="name" name="name" required>

    <label for="nationality">Nationality:</label>
    <?php if($errors->has('nationality') ): ?>
        <div class="text-red-700"><?php echo e($errors->first('nationality')); ?></div>
    <?php endif; ?>
    <input type="text" id="nationality" name="nationality" required>

    <label for="number">Number:</label>
    <?php if($errors->has('number') ): ?>
        <div class="text-red-700"><?php echo e($errors->first('number')); ?></div>
    <?php endif; ?>
    <input type="text" id="number" name="number" required>
    <button type="submit">Create</button>
</form>

</div>
<?php /**PATH C:\Users\moham\foootballcrud\resources\views/players/create.blade.php ENDPATH**/ ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/show.css'); ?>
    <title>Document</title>
</head>
<body>

<div class="container">
    <a class="players" href="<?php echo e(route('players.index')); ?>">← Back</a>

    <h1>Your chosen player:</h1>
<p>Name: <?php echo e($player->name); ?></p>
<p>Nationality:  <?php echo e($player->nationality); ?></p>
    <p>Number:  <?php echo e($player->number); ?></p>
</div>
</body>
</html>
<?php /**PATH C:\Users\moham\foootballcrud\resources\views/players/show.blade.php ENDPATH**/ ?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/edit.css'); ?>

    <title>Edit Player</title>
</head>
<body>

<div class="container">
    <a class="players" href="<?php echo e(route('players.index')); ?>">← Back</a>
<form action="<?php echo e(route('players.update', $player->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <label for="name">Name:</label>
    <?php if($errors->has('name') ): ?>
        <div class="text-red-700"><?php echo e($errors->first('name')); ?></div>
    <?php endif; ?>

    <input type="text" id="name" name="name" value="<?php echo e($player->name); ?>" required>

    <label for="Nat">Nationality:</label>
    <?php if($errors->has('nationality') ): ?>
        <div class="text-red-700"><?php echo e($errors->first('nationality')); ?></div>
    <?php endif; ?>
    <input type="text" id="nationality" name="nationality" value="<?php echo e($player->nationality); ?>" required>

    <label for="number">Number:</label>
    <?php if($errors->has('number') ): ?>
        <div class="text-red-700"><?php echo e($errors->first('number')); ?></div>
    <?php endif; ?>
    <input type="text" id="number" name="number" value="<?php echo e($player->number); ?>" required>
    <button type="submit">Update player</button>
</form>
</div>
</body>

</html>
<?php /**PATH C:\Users\moham\foootballcrud\resources\views/players/edit.blade.php ENDPATH**/ ?>
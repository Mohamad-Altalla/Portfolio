<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PlayersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('players')->insert([
            [
                'name' => 'Ronaldo',
                'nationality' => 'Portugal',
                'number' => 7
            ],[
                'name' => 'Messi',
                'nationality' => 'Argentina',
                'number' => 10


            ],[
                'name' => 'Neymar',
                'nationality' => 'Brazil',
                'number' => 10

            ],
        ]);
        //
    }
}

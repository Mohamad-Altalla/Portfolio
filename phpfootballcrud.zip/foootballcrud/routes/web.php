<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PlayersController;

Route::get('/', function () {
    return view('players.index');
});

Route::get('players/create', [PlayersController::class, 'create'])->name('players.create');
Route::post('players', [PlayersController::class, 'store'])->name('players.store');
Route::get('players/{id}/edit', [PlayersController::class, 'edit'])->name('players.edit');
Route::get('players/{id}', [PlayersController::class, 'show'])->name('players.show');
Route::put('players/{id}', [PlayersController::class, 'update'])->name('players.update');
Route::get('/', [PlayersController::class, 'index'])->name('players.index');
Route::delete('players/{id}', [PlayersController::class, 'destroy'])->name('players.destroy');

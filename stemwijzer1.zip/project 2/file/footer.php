<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">
    <title>footer</title>
</head>

<body>
    
    <footer>
        <p>Neutraal Kieslab ® 2024. Alle rechten voorbehouden.</p>
        <div>
            <a href="privacy.php">privacy</a>
            <a href="contcact.php">contact</a>
            <a href="https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=152&ct=1717581498&rver=7.0.6738.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d774218bf-3e47-5cc8-50b6-647ce14b87fe&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015">NeutraalKieslab@summacollege.nl</a>
        </div>
    </footer>
</body>

</html>
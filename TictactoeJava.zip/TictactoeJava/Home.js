document.addEventListener('DOMContentLoaded', function () {
  const board = document.getElementById('board');
  const status = document.getElementById('status');
  const cells = [];
  const restartButton = document.getElementById('restartButton');
  const botModeButton = document.getElementById('botModeButton');

  let currentPlayer = 'X';
  let gameEnded = false;
  let botMode = false;

  for (let i = 0; i < 9; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    cell.dataset.index = i;
    cell.addEventListener('click', handleCellClick);
    board.appendChild(cell);
    cells.push(cell);
  }
  function checkWin() {
    const winConditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], 
        [0, 3, 6], [1, 4, 7], [2, 5, 8], 
        [0, 4, 8], [2, 4, 6]
    ];

    for (const condition of winConditions) {
        const [a, b, c] = condition;
        if (cells[a].textContent &&
            cells[a].textContent == cells[b].textContent &&
            cells[a].textContent == cells[c].textContent) {
            cells[a].style.backgroundColor = cells[b].style.backgroundColor = cells[c].style.backgroundColor = 'lightgreen';
            status.textContent = `Speler ${currentPlayer} Wint!`;
            gameEnded = true;
            return true;
        }
    }
    return false;
}

  function checkDraw() {
    if (cells.every(cell => cell.textContent !== '')) {
      status.textContent = "Het is een gelijkspel!";
      return true;
    }
    return false;
  }



  restartButton.addEventListener('click', function () {

    cells.forEach(cell => {
        cell.textContent = '';
        cell.style.backgroundColor = ''; 
    });
  
    currentPlayer = 'X';
    gameEnded = false;
    status.textContent = `Player ${currentPlayer}'s Turn`;

});
  function handleCellClick(event) {
    if (gameEnded || (botMode && currentPlayer === 'O')) return;
    const cell = event.target;
    if (cell.textContent == '') {
      cell.textContent = currentPlayer;
      if (checkWin() || checkDraw()) {
        endGame();
      } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        status.textContent = `Player ${currentPlayer}'s Turn`;
        if (botMode && currentPlayer == 'O') {
          botMove();
        }
      }
    }
  }

  function botMove() {
    const emptyCells = cells.filter(cell => cell.textContent === '');
    if (emptyCells.length > 0) {
      const randomIndex = Math.floor(Math.random() * emptyCells.length);
      const selectedCell = emptyCells[randomIndex];
      selectedCell.textContent = currentPlayer;
      if (checkWin() || checkDraw()) {
        endGame();
      } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        status.textContent = `Player ${currentPlayer}'s Turn`;
      }
    }
  }

 

  restartButton.addEventListener('click', function () {
    
  });

  botModeButton.addEventListener('click', function () {
    botMode = !botMode;
    status.textContent = botMode ? "Bot Mode Enabled" : "";
    if (botMode && currentPlayer === 'O') {
      botMove();
    }
});

});
var timer;
var ele = document.getElementById('timer');

(function (){
  var sec = 0;
  timer = setInterval(()=>{
    ele.innerHTML = '00: '+sec;
    sec ++;
  }, 1000) 
})()
function Stop(params) {
    clearInterval(timer)
}